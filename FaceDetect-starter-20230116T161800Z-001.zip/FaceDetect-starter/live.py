# This script will detect faces via your webcam.
# This detection is perform in real time
# Tested with OpenCV3

import cv2
import time
import numpy as np

cap = cv2.VideoCapture(0)

width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

# Create the haar cascade
faceCascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
eyeCascade = cv2.CascadeClassifier("haarcascade_eye.xml")
smileCascade = cv2.CascadeClassifier("haarcascade_smile.xml")
bodyCascade = cv2.CascadeClassifier("haarcascade_upperbody.xml")

while(True):
	# TODO: Capture frame-by-frame
	ret, frame = cap.read()

	# TODO:  Our operations on the frame come here
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
	font = cv2.FONT_HERSHEY_DUPLEX
	cv2.putText(
		frame, "Press 'q' to quit", (50,50),font,
		1, (0,255,0), 2, cv2.LINE_4)
	
	# TODO:  Detect faces in the image
	faces = faceCascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(30, 30),
        )
	print("Found {0} faces!".format(len(faces)))

	# TODO: Draw a rectangle around the faces
	for (x, y, w, h) in faces:
		cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)

	# TODO: Display the resulting frame
	cv2.imshow("Frame", frame)
	if cv2.waitKey(1) & 0xFF == ord('q'):
		break

	time.sleep(0.1)
# When everything done, release the capture
cap.release()
cv2.destroyAllWindows()
